/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.opensharding.example.transaction.base.seata.raw.jdbc;

import io.opensharding.example.common.entity.Order;
import io.opensharding.example.common.entity.OrderItem;
import io.opensharding.example.common.service.CommonService;
import io.opensharding.example.common.entity.Order;
import io.opensharding.example.common.entity.OrderItem;
import io.opensharding.example.common.jdbc.repository.OrderItemRepositoryImpl;
import io.opensharding.example.common.jdbc.repository.OrderRepositoryImpl;
import io.opensharding.example.common.jdbc.service.CommonServiceImpl;
import io.opensharding.example.common.service.CommonService;
import org.apache.shardingsphere.shardingjdbc.api.yaml.YamlShardingDataSourceFactory;
import org.apache.shardingsphere.transaction.core.TransactionType;
import org.apache.shardingsphere.transaction.core.TransactionTypeHolder;

import javax.sql.DataSource;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.locks.LockSupport;

/*
    Please startup seata-server( before running this example.
    Download seata-server from here https://github.com/seata/seata/releases
 */
public class YamlConfigurationTransactionExample {
    
    private static String configFile = "/META-INF/sharding-databases-tables.yaml";
//    private static String configFile = "/META-INF/master-slave.yaml";
    
    public static void main(final String[] args) throws SQLException, IOException {
        DataSource dataSource = YamlShardingDataSourceFactory.createDataSource(getFile(configFile));
        CommonService commonService = getCommonService(dataSource);
        commonService.initEnvironment();
        processSeataTransaction(dataSource, commonService);
        commonService.cleanEnvironment();
    }
    
    private static File getFile(final String fileName) {
        return new File(Thread.currentThread().getClass().getResource(fileName).getFile());
    }
    
    private static CommonService getCommonService(final DataSource dataSource) {
        return new CommonServiceImpl(new OrderRepositoryImpl(dataSource), new OrderItemRepositoryImpl(dataSource));
    }
    
    private static void processSeataTransaction(final DataSource dataSource, final CommonService commonService) throws SQLException {
        TransactionTypeHolder.set(TransactionType.BASE);
        System.out.println("------############## Start seata succeed transaction ##################------");
        try (Connection connection = dataSource.getConnection()) {
            connection.setAutoCommit(false);
            insertSuccess(connection, commonService);
            connection.commit();
        }
        LockSupport.parkUntil(System.currentTimeMillis() + 1000);
        truncateTable(dataSource);
        System.out.println("------############## End seata succeed transaction ######################------");
        System.out.println("------############## Start seata failure transaction ############------");
        TransactionTypeHolder.set(TransactionType.BASE);
        Connection connection = dataSource.getConnection();
        try {
            connection.setAutoCommit(false);
            insertSuccess(connection, commonService);
            throw new SQLException("exception occur!");
        } catch (final SQLException ex) {
            connection.rollback();
        }
        commonService.printData();
        System.out.println("------############# End seata failure transaction #############------");
        truncateTable(dataSource);
    }
    
    private static void insertSuccess(final Connection connection, final CommonService commonService) throws SQLException {
        for (int i = 0; i < 10; i++) {
            Order order = new Order();
            order.setUserId(i);
            order.setStatus("SEATA-INIT");
            insertOrder(connection, order);
            OrderItem item = new OrderItem();
            item.setUserId(i);
            item.setOrderId(order.getOrderId());
            item.setStatus("SEATA-INIT");
            insertOrderItem(connection, item);
        }
        commonService.printData();
    }
    
    private static Long insertOrder(final Connection connection, final Order order) {
        String sql = "INSERT INTO t_order (user_id, status) VALUES (?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setObject(1, order.getUserId());
            preparedStatement.setObject(2, order.getStatus());
            preparedStatement.executeUpdate();
            try (ResultSet resultSet = preparedStatement.getGeneratedKeys()) {
                if (resultSet.next()) {
                    order.setOrderId(resultSet.getLong(1));
                }
            }
        } catch (final SQLException ignored) {
        }
        return order.getOrderId();
    }
    
    private static Long insertOrderItem(final Connection connection, final OrderItem orderItem) {
        String sql = "INSERT INTO t_order_item (order_id, user_id, status) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setObject(1, orderItem.getOrderId());
            preparedStatement.setObject(2, orderItem.getUserId());
            preparedStatement.setString(3, orderItem.getStatus());
            preparedStatement.executeUpdate();
            try (ResultSet resultSet = preparedStatement.getGeneratedKeys()) {
                if (resultSet.next()) {
                    orderItem.setOrderItemId(resultSet.getLong(1));
                }
            }
        } catch (final SQLException ignored) {
        }
        return orderItem.getOrderItemId();
    }
    
    private static void truncateTable(final DataSource dataSource) {
        OrderRepositoryImpl orderRepository = new OrderRepositoryImpl(dataSource);
        OrderItemRepositoryImpl orderItemRepository = new OrderItemRepositoryImpl(dataSource);
        orderRepository.truncateTable();
        orderItemRepository.truncateTable();
    }
}
