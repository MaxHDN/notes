package com.lagou;

import org.springframework.boot.autoconfigure.SpringBootApplication;

//@EnableTransactionManagement
@SpringBootApplication
public class RunBoot {
}
